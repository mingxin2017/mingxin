/**
 * @fileOverview Dom 操作相关
 */
define([
    './dollar-third'
], function( _ ) {
    return _;
});